/*
**             Copyright 2017 by Kvaser AB, Molndal, Sweden
**                         http://www.kvaser.com
**
** This software is dual licensed under the following two licenses:
** BSD-new and GPLv2. You may use either one. See the included
** COPYING file for details.
**
** License: BSD-new
** ==============================================================================
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are met:
**     * Redistributions of source code must retain the above copyright
**       notice, this list of conditions and the following disclaimer.
**     * Redistributions in binary form must reproduce the above copyright
**       notice, this list of conditions and the following disclaimer in the
**       documentation and/or other materials provided with the distribution.
**     * Neither the name of the <organization> nor the
**       names of its contributors may be used to endorse or promote products
**       derived from this software without specific prior written permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
** BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
** IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
**
** License: GPLv2
** ==============================================================================
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
**
**
** IMPORTANT NOTICE:
** ==============================================================================
** This source code is made available for free, as an open license, by Kvaser AB,
** for use with its applications. Kvaser AB does not accept any liability
** whatsoever for any third party patent or other immaterial property rights
** violations that may result from any usage of this source code, regardless of
** the combination of source code and various applications that it can be used
** in, or with.
**
** -----------------------------------------------------------------------------
*/

/*
** Description:
**  Read, write and convert KME files.
** -----------------------------------------------------------------------------
*/

#ifndef FILEHANDLER_H
#define FILEHANDLER_H

#include <inttypes.h>
typedef void* FileHandle;
#define INVALID_FILE_HANDLE_VALUE NULL
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif


typedef enum {
  FileStatusOK                      =  0,
  FileStatusFail                    = -1,
  FileStatusERR_PARAM               = -3,
  FileStatusERR_NOLOGMSG            = -10,
  FileStatusERR_QUEUE_FULL          = -20,
  FileStatusERR_FILE_ERROR          = -23,
  FileStatusERR_NOT_IMPLEMENTED     = -30,
  FileStatusERR_ILLEGAL_REQUEST     = -32,
  FileStatusERR_FILE_NOT_FOUND      = -33,
  FileStatusERR_WRITE_PROT          = -42,
  FileStatusERR_INVALID_HANDLE      = -43,
  FileStatusERR_NO_FREE_HANDLE      = -44,
} FileStatus;

// Equal to the file types in kvlclib.h
typedef enum {
  KME24             = 1,
  KME25             = 2,
  KME40             = 7,
  KME50             = 9,
  KME60             = 10,
  UNKNOWN_FILE_TYPE = -100,
} FileType;


FileHandle openFile (const char *filename, FileStatus *status,  FileType type);

FileHandle createFile (const char *filename, FileStatus *status,  FileType type);

FileStatus closeFile (FileHandle h);

FileStatus countEvents (FileHandle h, uint64_t *count );

// Must be called with a pointer to memoLogEventEx
FileStatus readEvent (FileHandle h, void *e);

// Must be called with a pointer to memoLogEventEx
FileStatus writeEvent (FileHandle h, void *e);

#ifdef __cplusplus
}
#endif

#endif //FILEHANDLER_H
