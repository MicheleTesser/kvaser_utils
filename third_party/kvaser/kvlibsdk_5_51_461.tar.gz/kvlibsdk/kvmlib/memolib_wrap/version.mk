LIBNAME = libkvamemolib.so
MAJOR = 1
MINOR = 5
BUILD = 14